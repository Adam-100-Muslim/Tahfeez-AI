import React from 'react';
import { BookOpenIcon } from '../IconComponents';

interface OnboardingWelcomeProps {
    onContinue: () => void;
}

const OnboardingWelcome: React.FC<OnboardingWelcomeProps> = ({ onContinue }) => {
    return (
        <div className="flex flex-col items-center justify-center min-h-screen p-6 text-center bg-white text-slate-800">
            <div className="max-w-md animate-fade-in">
                <BookOpenIcon className="w-24 h-24 mx-auto mb-6 text-emerald-500" />
                <h1 className="text-5xl font-bold mb-4">Welcome to Quranic Quest</h1>
                <p className="text-lg text-slate-600 mb-12">
                    Embark on a journey to understand the Quran, one verse at a time.
                </p>
                <button
                    onClick={onContinue}
                    className="w-full max-w-sm bg-emerald-500 text-white font-bold py-4 px-8 rounded-xl text-lg shadow-lg transition-transform transform hover:scale-105 hover:bg-emerald-600"
                >
                    Get Started
                </button>
            </div>
            <style>{`
                @keyframes fade-in {
                    from { opacity: 0; transform: translateY(10px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-fade-in {
                    animation: fade-in 0.5s ease-out forwards;
                }
            `}</style>
        </div>
    );
};

export default OnboardingWelcome;
