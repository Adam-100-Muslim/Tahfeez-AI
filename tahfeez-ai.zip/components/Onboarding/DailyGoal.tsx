import React, { useState } from 'react';
import OnboardingLayout from './OnboardingLayout';

interface DailyGoalProps {
    onContinue: (minutes: number) => void;
}

const goals = [
    { minutes: 5, label: "Casual", description: "5 minutes / day" },
    { minutes: 10, label: "Regular", description: "10 minutes / day" },
    { minutes: 15, label: "Serious", description: "15 minutes / day" },
    { minutes: 20, label: "Intense", description: "20 minutes / day" },
];

const OptionButton: React.FC<{
    onClick: () => void;
    isSelected: boolean;
    children: React.ReactNode;
}> = ({ onClick, isSelected, children }) => (
    <button
        onClick={onClick}
        className={`w-full p-5 border-2 rounded-xl text-left transition-all duration-200 flex justify-between items-center
            ${isSelected
                ? 'bg-sky-100 border-sky-500 ring-2 ring-sky-500 text-sky-800'
                : 'bg-white border-slate-300 hover:bg-slate-50 text-slate-700'
            }`}
    >
        {children}
        {isSelected && (
            <div className="w-6 h-6 rounded-full bg-sky-500 flex items-center justify-center flex-shrink-0">
                <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
            </div>
        )}
    </button>
);


const DailyGoal: React.FC<DailyGoalProps> = ({ onContinue }) => {
    const [selectedGoal, setSelectedGoal] = useState<number | null>(null);

    return (
        <OnboardingLayout
            title="What's your daily goal?"
            onContinue={() => selectedGoal && onContinue(selectedGoal)}
            isContinueDisabled={selectedGoal === null}
        >
            <div className="space-y-4">
                {goals.map(({ minutes, label, description }) => (
                     <OptionButton
                        key={minutes}
                        onClick={() => setSelectedGoal(minutes)}
                        isSelected={selectedGoal === minutes}
                     >
                        <div>
                            <p className="font-bold text-lg">{label}</p>
                            <p className="text-sm">{description}</p>
                        </div>
                    </OptionButton>
                ))}
            </div>
        </OnboardingLayout>
    );
};

export default DailyGoal;
