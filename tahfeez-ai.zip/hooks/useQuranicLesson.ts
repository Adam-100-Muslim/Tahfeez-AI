
import { useState, useEffect, useCallback } from 'react';
import type { LessonData, Question } from '../types';
import { LessonStatus } from '../types';
import { generateLessonContent } from '../services/geminiService';

export const useQuranicLesson = (surah: string, ayah: number) => {
    const [status, setStatus] = useState<LessonStatus>(LessonStatus.IDLE);
    const [lessonData, setLessonData] = useState<LessonData | null>(null);
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
    const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
    const [score, setScore] = useState(0);
    const [hearts, setHearts] = useState(5);
    const [error, setError] = useState<string | null>(null);

    const loadLesson = useCallback(async () => {
        setStatus(LessonStatus.LOADING);
        setError(null);
        try {
            const data = await generateLessonContent(surah, ayah);
            setLessonData(data);
            setStatus(LessonStatus.ACTIVE);
            setCurrentQuestionIndex(0);
            setSelectedAnswer(null);
            setIsCorrect(null);
            setScore(0);
            setHearts(5);
        } catch (e) {
            setError(e instanceof Error ? e.message : "An unknown error occurred.");
            setStatus(LessonStatus.ERROR);
        }
    }, [surah, ayah]);

    useEffect(() => {
        loadLesson();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [surah, ayah]);

    const currentQuestion: Question | null = lessonData ? lessonData.questions[currentQuestionIndex] : null;

    const handleSelectAnswer = (answer: string) => {
        if (status === LessonStatus.ACTIVE) {
            setSelectedAnswer(answer);
        }
    };

    const checkAnswer = () => {
        if (!selectedAnswer || !currentQuestion) return;

        const correct = selectedAnswer === currentQuestion.correctAnswer;
        setIsCorrect(correct);
        setStatus(LessonStatus.ANSWERED);

        if (correct) {
            setScore(prev => prev + 10);
        } else {
            setHearts(prev => Math.max(0, prev - 1));
        }
    };

    const nextQuestion = () => {
        if (hearts === 0) {
            setStatus(LessonStatus.COMPLETED);
            return;
        }

        const nextIndex = currentQuestionIndex + 1;
        if (lessonData && nextIndex < lessonData.questions.length) {
            setCurrentQuestionIndex(nextIndex);
            setSelectedAnswer(null);
            setIsCorrect(null);
            setStatus(LessonStatus.ACTIVE);
        } else {
            setStatus(LessonStatus.COMPLETED);
        }
    };

    const progress = lessonData ? ((currentQuestionIndex) / lessonData.questions.length) * 100 : 0;
    
    return {
        status,
        lessonData,
        currentQuestion,
        selectedAnswer,
        isCorrect,
        score,
        hearts,
        progress,
        error,
        handleSelectAnswer,
        checkAnswer,
        nextQuestion,
        retry: loadLesson,
    };
};
