
import React from 'react';
import type { Question, VerseDetails } from '../types';

interface QuestionCardProps {
    verseDetails: VerseDetails;
    question: Question;
    selectedAnswer: string | null;
    onSelectAnswer: (answer: string) => void;
    status: 'active' | 'answered';
}

const OptionButton: React.FC<{
    option: string;
    isSelected: boolean;
    isCorrect: boolean;
    isRevealed: boolean;
    onClick: () => void;
}> = ({ option, isSelected, isCorrect, isRevealed, onClick }) => {

    const getButtonClass = () => {
        if (isRevealed) {
            if (isCorrect) return 'bg-green-100 border-green-500 text-green-800 ring-2 ring-green-500';
            if (isSelected && !isCorrect) return 'bg-red-100 border-red-500 text-red-800 ring-2 ring-red-500';
            return 'bg-slate-100 border-slate-300 text-slate-500';
        }

        if (isSelected) {
            return 'bg-sky-100 border-sky-500 ring-2 ring-sky-500 text-sky-800';
        }

        return 'bg-white border-slate-300 hover:bg-slate-50 text-slate-700';
    };

    return (
        <button
            onClick={onClick}
            disabled={isRevealed}
            className={`w-full p-4 border-2 rounded-xl text-left font-semibold text-base transition-all duration-200 ${getButtonClass()}`}
        >
            {option}
        </button>
    );
};

const QuestionCard: React.FC<QuestionCardProps> = ({ verseDetails, question, selectedAnswer, onSelectAnswer, status }) => {

    const isRevealed = status === 'answered';

    return (
        <div className="w-full">
            <h2 className="text-xl font-bold text-slate-800 mb-6">Translate this verse</h2>
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 mb-8 text-center">
                 <p lang="ar" dir="rtl" className="font-arabic text-4xl text-slate-800 mb-3">
                    {verseDetails.arabicText}
                </p>
                <p className="font-sans text-lg text-emerald-600 font-medium italic">
                    {verseDetails.transliteration}
                </p>
            </div>
            
            <h3 className="text-lg font-semibold text-slate-700 mb-4">{question.questionText}</h3>
            
            <div className="space-y-3">
                {question.options.map((option, index) => (
                    <OptionButton
                        key={index}
                        option={option}
                        isSelected={selectedAnswer === option}
                        isCorrect={option === question.correctAnswer}
                        isRevealed={isRevealed}
                        onClick={() => onSelectAnswer(option)}
                    />
                ))}
            </div>
        </div>
    );
};

export default QuestionCard;
