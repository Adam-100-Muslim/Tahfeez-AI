import React from 'react';

interface CourseHubLayoutProps {
    title: string;
    subtitle: string;
    children: React.ReactNode;
}

const CourseHubLayout: React.FC<CourseHubLayoutProps> = ({ title, subtitle, children }) => {
    return (
        <div className="w-full max-w-5xl mx-auto p-4 sm:p-6">
            <header className="mb-8">
                <h1 className="text-4xl font-bold text-slate-800">{title}</h1>
                <p className="text-lg text-slate-500 mt-1">{subtitle}</p>
            </header>
            <main>
                {children}
            </main>
        </div>
    );
};

export default CourseHubLayout;