import React from 'react';

interface OnboardingLayoutProps {
    title: string;
    children: React.ReactNode;
    onContinue: () => void;
    continueText?: string;
    isContinueDisabled?: boolean;
}

const OnboardingLayout: React.FC<OnboardingLayoutProps> = ({ title, children, onContinue, continueText = "Continue", isContinueDisabled = false }) => {
    return (
        <div className="flex flex-col min-h-screen">
            <main className="flex-grow w-full max-w-2xl mx-auto px-4 flex flex-col justify-center text-center">
                <h1 className="text-3xl font-bold text-slate-800 mb-8">{title}</h1>
                {children}
            </main>
            <footer className="w-full border-t border-slate-200 bg-white/80 backdrop-blur-sm sticky bottom-0">
                <div className="max-w-2xl mx-auto p-4">
                    <button
                        onClick={onContinue}
                        disabled={isContinueDisabled}
                        className="w-full bg-emerald-500 text-white font-bold py-4 rounded-xl text-lg shadow-lg transition-all duration-200 enabled:hover:bg-emerald-600 enabled:active:scale-95 disabled:bg-slate-300 disabled:cursor-not-allowed"
                    >
                        {continueText}
                    </button>
                </div>
            </footer>
        </div>
    );
};

export default OnboardingLayout;
