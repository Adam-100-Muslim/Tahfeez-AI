
export interface Question {
  questionText: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
}

export interface VerseDetails {
  arabicText: string;
  transliteration: string;
  translation: string;
  explanation: string;
}

export interface LessonData {
  verseDetails: VerseDetails;
  questions: Question[];
}

export enum LessonStatus {
  IDLE,
  LOADING,
  ACTIVE,
  ANSWERED,
  COMPLETED,
  ERROR
}
