import React, { useState } from 'react';
import OnboardingLayout from './OnboardingLayout';

interface LevelSelectProps {
    onContinue: (level: string) => void;
}

const levels = [
    { id: 'beginner', name: 'Beginner', description: 'Just starting my journey, learning the basics.' },
    { id: 'intermediate', name: 'Intermediate', description: 'I have some knowledge and want to deepen it.' },
    { id: 'expert', name: 'Expert', description: 'I am proficient and looking for advanced study.' },
];

const OptionButton: React.FC<{
    onClick: () => void;
    isSelected: boolean;
    children: React.ReactNode;
}> = ({ onClick, isSelected, children }) => (
    <button
        onClick={onClick}
        className={`w-full p-5 border-2 rounded-xl text-left transition-all duration-200
            ${isSelected
                ? 'bg-sky-100 border-sky-500 ring-2 ring-sky-500 text-sky-800'
                : 'bg-white border-slate-300 hover:bg-slate-50 text-slate-700'
            }`}
    >
        {children}
    </button>
);

const LevelSelect: React.FC<LevelSelectProps> = ({ onContinue }) => {
    const [selectedLevel, setSelectedLevel] = useState<string | null>(null);

    return (
        <OnboardingLayout
            title="What's your current level?"
            onContinue={() => selectedLevel && onContinue(selectedLevel)}
            isContinueDisabled={selectedLevel === null}
        >
            <div className="space-y-4">
                {levels.map(({ id, name, description }) => (
                     <OptionButton
                        key={id}
                        onClick={() => setSelectedLevel(id)}
                        isSelected={selectedLevel === id}
                    >
                        <div>
                            <p className="font-bold text-lg">{name}</p>
                            <p className="text-sm text-slate-600">{description}</p>
                        </div>
                    </OptionButton>
                ))}
            </div>
        </OnboardingLayout>
    );
};

export default LevelSelect;
