import React, { useState } from 'react';
import OnboardingLayout from './OnboardingLayout';

interface CourseSelectProps {
    onStart: (course: string) => void;
}

const courses = [
    { id: 'alphabets', name: 'Arabic Alphabets', description: 'Learn to read and write the foundational letters.' },
    { id: 'quran', name: 'Quran', description: 'Study verses, translations, and tafsir.' },
    { id: 'adhkaars', name: 'Adhkaar', description: 'Memorize daily supplications.' },
    { id: 'salah', name: 'Salah Dhikrs', description: 'Learn the supplications within the prayer.' },
];

const OptionButton: React.FC<{
    onClick: () => void;
    isSelected: boolean;
    children: React.ReactNode;
}> = ({ onClick, isSelected, children }) => (
    <button
        onClick={onClick}
        className={`w-full p-5 border-2 rounded-xl text-left transition-all duration-200
            ${isSelected
                ? 'bg-sky-100 border-sky-500 ring-2 ring-sky-500 text-sky-800'
                : 'bg-white border-slate-300 hover:bg-slate-50 text-slate-700'
            }`}
    >
        {children}
    </button>
);


const CourseSelect: React.FC<CourseSelectProps> = ({ onStart }) => {
    const [selectedCourse, setSelectedCourse] = useState<string | null>(null);

    return (
        <OnboardingLayout
            title="What would you like to learn?"
            onContinue={() => selectedCourse && onStart(selectedCourse)}
            continueText="Start Learning"
            isContinueDisabled={selectedCourse === null}
        >
            <div className="space-y-4">
                 {courses.map(({ id, name, description }) => (
                     <OptionButton
                        key={id}
                        onClick={() => setSelectedCourse(id)}
                        isSelected={selectedCourse === id}
                    >
                         <div>
                            <p className="font-bold text-lg">{name}</p>
                            <p className="text-sm text-slate-600">{description}</p>
                        </div>
                    </OptionButton>
                ))}
            </div>
        </OnboardingLayout>
    );
};

export default CourseSelect;
