import React from 'react';
import CourseHubLayout from './CourseHubLayout';

const salahDhikrsList = [
    { title: "Dua Al-Istiftaah", description: "The opening supplication after Takbir." },
    { title: "Dhikr in Ruku'", description: "Glorification in the bowing position." },
    { title: "Dua after Ruku'", description: "Praise upon rising from bowing." },
    { title: "Dhikr in Sujood", description: "Glorification in prostration." },
    { title: "Dua between Two Sajdahs", description: "Supplication while sitting between prostrations." },
    { title: "At-Tashahhud", description: "The testimony of faith." },
    { title: "As-Salat Al-Ibrahimiyyah", description: "Sending prayers upon the Prophet." },
    { title: "Dua before Tasleem", description: "Final supplications before ending prayer." },
];

const SalahDhikrsHub: React.FC = () => {
    return (
        <CourseHubLayout
            title="Dhikrs of Salah"
            subtitle="Learn and perfect the supplications recited within the prayer."
        >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {salahDhikrsList.map((item, index) => (
                    <div key={index} className="p-5 bg-white rounded-xl shadow-md border border-slate-200 flex flex-col justify-between">
                        <div>
                            <h3 className="text-lg font-bold text-slate-800">{item.title}</h3>
                            <p className="text-slate-600 text-sm mt-1">{item.description}</p>
                        </div>
                        <button className="mt-4 w-full bg-slate-200 text-slate-500 font-bold py-2 px-4 rounded-lg cursor-not-allowed">
                            Coming Soon
                        </button>
                    </div>
                ))}
            </div>
        </CourseHubLayout>
    );
};

export default SalahDhikrsHub;
