
import { GoogleGenAI, Type } from "@google/genai";
import type { LessonData } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const lessonSchema = {
    type: Type.OBJECT,
    properties: {
        verseDetails: {
            type: Type.OBJECT,
            properties: {
                arabicText: { type: Type.STRING, description: "The verse in its original Arabic script." },
                transliteration: { type: Type.STRING, description: "An accurate English transliteration of the verse." },
                translation: { type: Type.STRING, description: "A clear and common English translation of the verse." },
                explanation: { type: Type.STRING, description: "A brief, easy-to-understand explanation (tafsir) of the verse, suitable for a beginner." },
            },
            required: ["arabicText", "transliteration", "translation", "explanation"]
        },
        questions: {
            type: Type.ARRAY,
            description: "An array of 4 multiple-choice questions to test comprehension.",
            items: {
                type: Type.OBJECT,
                properties: {
                    questionText: { type: Type.STRING, description: "The question text." },
                    options: { 
                        type: Type.ARRAY, 
                        description: "An array of 4 strings: one correct answer and three plausible distractors.",
                        items: { type: Type.STRING } 
                    },
                    correctAnswer: { type: Type.STRING, description: "The correct answer, which must be one of the options." },
                    explanation: { type: Type.STRING, description: "A brief explanation for why the answer is correct." },
                },
                required: ["questionText", "options", "correctAnswer", "explanation"]
            }
        }
    },
    required: ["verseDetails", "questions"]
};

export const generateLessonContent = async (surah: string, ayah: number): Promise<LessonData> => {
    const prompt = `
        You are an expert Quranic studies teacher and curriculum designer, specializing in creating engaging learning materials for English speakers. 
        Your task is to generate a complete, self-contained lesson for a single Quranic verse.

        Generate a lesson for: Surah ${surah}, Ayah ${ayah}.

        Provide the output in a valid JSON format that adheres to the provided schema.

        The lesson must include:
        1. The verse in its original Arabic script.
        2. An accurate English transliteration.
        3. A clear and common English translation.
        4. A brief, easy-to-understand explanation (tafsir) of the verse, suitable for a beginner.
        5. An array of exactly 4 multiple-choice questions designed to test comprehension of the verse's vocabulary and meaning. For each question, provide four options: one correct answer and three plausible distractors. The correctAnswer field must exactly match one of the provided options.

        Do not include any introductory text or explanations outside of the JSON object.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: lessonSchema,
            },
        });
        
        const jsonText = response.text.trim();
        const lesson = JSON.parse(jsonText);

        // Basic validation
        if (!lesson.verseDetails || !lesson.questions || lesson.questions.length === 0) {
            throw new Error("Generated lesson data is incomplete.");
        }

        return lesson as LessonData;
    } catch (error) {
        console.error("Error generating lesson content:", error);
        throw new Error("Failed to generate lesson from AI. Please try again.");
    }
};
