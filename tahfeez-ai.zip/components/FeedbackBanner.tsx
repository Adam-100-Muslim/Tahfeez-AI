
import React from 'react';
import { CheckCircleIcon, XCircleIcon } from './IconComponents';

interface FeedbackBannerProps {
    isCorrect: boolean;
    correctAnswer: string;
    explanation: string;
    onContinue: () => void;
}

const FeedbackBanner: React.FC<FeedbackBannerProps> = ({ isCorrect, correctAnswer, explanation, onContinue }) => {
    const bgColor = isCorrect ? 'bg-green-100' : 'bg-red-100';
    const textColor = isCorrect ? 'text-green-700' : 'text-red-700';
    const buttonColor = isCorrect ? 'bg-green-500 hover:bg-green-600' : 'bg-red-500 hover:bg-red-600';
    const Icon = isCorrect ? CheckCircleIcon : XCircleIcon;

    return (
        <div className={`fixed bottom-0 left-0 right-0 p-6 ${bgColor} ${textColor} border-t-2 ${isCorrect ? 'border-green-200' : 'border-red-200'}`}>
            <div className="max-w-4xl mx-auto">
                <div className="flex items-start md:items-center justify-between">
                    <div className="flex items-start space-x-4">
                        <Icon className={`w-10 h-10 ${isCorrect ? 'text-green-500' : 'text-red-500'}`} />
                        <div>
                            <h3 className="font-bold text-lg">{isCorrect ? 'Excellent!' : 'Correct solution:'}</h3>
                            <p className="text-base font-semibold">{isCorrect ? explanation : correctAnswer}</p>
                             {!isCorrect && <p className="text-sm mt-1">{explanation}</p>}
                        </div>
                    </div>
                    <button 
                        onClick={onContinue}
                        className={`text-white font-bold py-3 px-8 rounded-xl shadow-lg transition-transform transform hover:scale-105 ${buttonColor}`}
                    >
                        Continue
                    </button>
                </div>
            </div>
        </div>
    );
};

export default FeedbackBanner;
