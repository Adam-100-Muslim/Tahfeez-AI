import React from 'react';
import { useQuranicLesson } from '../hooks/useQuranicLesson';
import { LessonStatus } from '../types';
import Header from './Header';
import ProgressBar from './ProgressBar';
import QuestionCard from './QuestionCard';
import FeedbackBanner from './FeedbackBanner';
import LessonComplete from './LessonComplete';
import { LoadingSpinner, BookOpenIcon } from './IconComponents';

interface LessonViewProps {
  surah: string;
  ayah: number;
  lessonTitle: string;
  onLessonComplete: () => void;
}

const LessonView: React.FC<LessonViewProps> = ({ surah, ayah, lessonTitle, onLessonComplete }) => {
    const {
        status,
        lessonData,
        currentQuestion,
        selectedAnswer,
        isCorrect,
        score,
        hearts,
        progress,
        error,
        handleSelectAnswer,
        checkAnswer,
        nextQuestion,
        retry,
    } = useQuranicLesson(surah, ayah);

    const renderContent = () => {
        switch (status) {
            case LessonStatus.LOADING:
                return (
                    <div className="flex flex-col items-center justify-center h-full text-slate-600">
                        <LoadingSpinner className="w-16 h-16 mb-4" />
                        <p className="text-lg font-semibold">Generating your lesson...</p>
                        <p>Please wait a moment.</p>
                    </div>
                );

            case LessonStatus.ERROR:
                return (
                     <div className="flex flex-col items-center justify-center h-full text-center text-red-600">
                        <BookOpenIcon className="w-16 h-16 mb-4" />
                        <h2 className="text-2xl font-bold mb-2">Oops! Something went wrong.</h2>
                        <p className="mb-4">{error}</p>
                        <button
                            onClick={retry}
                            className="bg-red-500 text-white font-bold py-3 px-6 rounded-xl hover:bg-red-600"
                        >
                            Try Again
                        </button>
                    </div>
                );
                
            case LessonStatus.COMPLETED:
                return <LessonComplete 
                    score={score} 
                    totalQuestions={lessonData?.questions.length || 0} 
                    onRetry={retry}
                    onComplete={onLessonComplete}
                />;

            case LessonStatus.ACTIVE:
            case LessonStatus.ANSWERED:
                if (!lessonData || !currentQuestion) {
                    return <div>Error: Lesson data is missing.</div>;
                }
                return (
                    <>
                        <ProgressBar progress={progress} />
                        <QuestionCard
                            verseDetails={lessonData.verseDetails}
                            question={currentQuestion}
                            selectedAnswer={selectedAnswer}
                            onSelectAnswer={handleSelectAnswer}
                            status={status === LessonStatus.ACTIVE ? 'active' : 'answered'}
                        />
                    </>
                );
                
            default:
                return null;
        }
    };

    const isCheckButtonDisabled = selectedAnswer === null || status === LessonStatus.ANSWERED;

    return (
        <div className="flex flex-col min-h-screen">
             <Header hearts={hearts} lessonTitle={lessonTitle} />
            <main className="flex-grow w-full max-w-4xl mx-auto px-4 flex flex-col justify-center">
                {renderContent()}
            </main>
            { status !== LessonStatus.COMPLETED && (
                <footer className="w-full border-t border-slate-200">
                    <div className="max-w-4xl mx-auto p-4">
                        {status === LessonStatus.ACTIVE && (
                            <button
                                onClick={checkAnswer}
                                disabled={isCheckButtonDisabled}
                                className="w-full bg-emerald-500 text-white font-bold py-4 rounded-xl text-lg shadow-lg transition-all duration-200 enabled:hover:bg-emerald-600 enabled:active:scale-95 disabled:bg-slate-300 disabled:cursor-not-allowed"
                            >
                                Check
                            </button>
                        )}
                    </div>
                </footer>
            )}
            {status === LessonStatus.ANSWERED && isCorrect !== null && (
                 <FeedbackBanner 
                    isCorrect={isCorrect}
                    correctAnswer={currentQuestion?.correctAnswer || ''}
                    explanation={currentQuestion?.explanation || ''}
                    onContinue={nextQuestion}
                />
            )}
        </div>
    );
};

export default LessonView;