import React from 'react';
import CourseHubLayout from './CourseHubLayout';

const letterGroups = [
    ['ا', 'ب', 'ت', 'ث'],
    ['ج', 'ح', 'خ', 'د'],
    ['ذ', 'ر', 'ز', 'س'],
    ['ش', 'ص', 'ض', 'ط'],
    ['ظ', 'ع', 'غ', 'ف'],
    ['ق', 'ك', 'ل', 'م'],
    ['ن', 'ه', 'و', 'ي'],
];

const AlphabetHub: React.FC = () => {
    return (
        <CourseHubLayout
            title="Arabic Alphabets"
            subtitle="Learn to read and write the foundational letters. Select a group to start."
        >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {letterGroups.map((group, index) => (
                    <div key={index} className="p-6 bg-white rounded-2xl shadow-lg border border-slate-200 flex flex-col items-center">
                        <h3 className="text-xl font-bold text-slate-700 mb-4">Group {index + 1}</h3>
                        <div dir="rtl" className="flex flex-wrap-reverse justify-center gap-4 font-arabic text-5xl text-emerald-600">
                            {group.map(letter => (
                                <span key={letter}>{letter}</span>
                            ))}
                        </div>
                        <button className="mt-6 w-full bg-slate-200 text-slate-500 font-bold py-2 px-4 rounded-lg cursor-not-allowed">
                            Coming Soon
                        </button>
                    </div>
                ))}
            </div>
        </CourseHubLayout>
    );
};

export default AlphabetHub;
