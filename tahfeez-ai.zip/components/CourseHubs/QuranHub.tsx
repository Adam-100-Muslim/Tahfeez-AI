import React, { useState, useMemo } from 'react';
import { surahs, SurahInfo } from '../../data/quranInfo';
import CourseHubLayout from './CourseHubLayout';
import { ArrowLeftIcon } from '../IconComponents';

interface QuranHubProps {
    onStartLesson: (surah: string, ayah: number) => void;
}

const QuranHub: React.FC<QuranHubProps> = ({ onStartLesson }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedSurah, setSelectedSurah] = useState<SurahInfo | null>(null);
    const [ayahInput, setAyahInput] = useState('');
    const [error, setError] = useState('');

    const filteredSurahs = useMemo(() => {
        return surahs.filter(surah =>
            surah.englishName.toLowerCase().includes(searchTerm.toLowerCase()) ||
            surah.name.includes(searchTerm) ||
            surah.number.toString().includes(searchTerm)
        );
    }, [searchTerm]);

    const handleSelectSurah = (surah: SurahInfo) => {
        setSelectedSurah(surah);
        setAyahInput('');
        setError('');
    };

    const handleBackToList = () => {
        setSelectedSurah(null);
    };

    const handleStart = () => {
        const ayahNumber = parseInt(ayahInput, 10);
        if (!selectedSurah) return;

        if (isNaN(ayahNumber) || ayahNumber < 1 || ayahNumber > selectedSurah.ayahs) {
            setError(`Please enter a valid verse number between 1 and ${selectedSurah.ayahs}.`);
            return;
        }
        setError('');
        onStartLesson(selectedSurah.englishName, ayahNumber);
    };

    if (selectedSurah) {
        return (
            <div className="w-full max-w-2xl mx-auto p-4 flex flex-col justify-center min-h-screen">
                <button onClick={handleBackToList} className="flex items-center space-x-2 text-slate-500 hover:text-emerald-600 font-semibold mb-6">
                    <ArrowLeftIcon className="w-5 h-5" />
                    <span>Back to Surah List</span>
                </button>
                <div className="bg-white p-8 rounded-2xl shadow-lg border border-slate-200 text-center">
                    <h2 className="text-3xl font-bold text-slate-800">{selectedSurah.englishName}</h2>
                    <p lang="ar" dir="rtl" className="font-arabic text-2xl text-emerald-600 mb-4">{selectedSurah.name}</p>
                    <p className="text-slate-500 mb-6">{selectedSurah.ayahs} verses ({selectedSurah.revelationType})</p>
                    
                    <div className="flex flex-col items-center">
                         <label htmlFor="ayah-input" className="font-semibold text-slate-700 mb-2">Choose a verse to study</label>
                         <input
                            id="ayah-input"
                            type="number"
                            value={ayahInput}
                            onChange={(e) => setAyahInput(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleStart()}
                            min="1"
                            max={selectedSurah.ayahs}
                            placeholder={`Verse (1-${selectedSurah.ayahs})`}
                            className="w-full max-w-xs p-3 text-center border-2 border-slate-300 rounded-lg focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition"
                         />
                         {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
                    </div>

                     <button
                        onClick={handleStart}
                        className="w-full max-w-xs mt-6 bg-emerald-500 text-white font-bold py-3 px-6 rounded-xl shadow-lg hover:bg-emerald-600 transition-all duration-200 transform hover:scale-105"
                    >
                        Start Lesson
                    </button>
                </div>
            </div>
        )
    }

    return (
        <CourseHubLayout title="Learn the Quran" subtitle="Select a Surah to begin your journey.">
            <div className="mb-8">
                <input
                    type="text"
                    placeholder="Search for a Surah by name or number..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full p-4 border-2 border-slate-300 rounded-xl focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition"
                />
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredSurahs.map(surah => (
                    <button
                        key={surah.number}
                        onClick={() => handleSelectSurah(surah)}
                        className="p-4 bg-white rounded-xl shadow-sm border border-slate-200 hover:border-emerald-500 hover:ring-2 hover:ring-emerald-500 text-left transition-all duration-200 flex flex-col justify-between h-full"
                    >
                        <div>
                            <div className="flex justify-between items-baseline">
                                <p className="font-bold text-slate-800">{surah.englishName}</p>
                                <span className="text-sm font-mono text-slate-400">{surah.number}</span>
                            </div>
                            <p lang="ar" dir="rtl" className="font-arabic text-lg text-emerald-600 text-right">{surah.name}</p>
                        </div>
                        <p className="text-sm text-slate-500 mt-2">{surah.ayahs} verses</p>
                    </button>
                ))}
            </div>
        </CourseHubLayout>
    );
};

export default QuranHub;
