import React from 'react';
import CourseHubLayout from './CourseHubLayout';

const adhkaarList = [
    { title: "Morning Adhkaar", description: "Supplications for the morning." },
    { title: "Evening Adhkaar", description: "Supplications for the evening." },
    { title: "Before Sleeping", description: "What to say before you sleep." },
    { title: "Waking Up", description: "The first words upon waking." },
    { title: "Entering/Leaving Home", description: "Protection for your home." },
    { title: "Before/After Eating", description: "Gratitude for your provisions." },
    { title: "Dressing", description: "Supplication for wearing clothes." },
    { title: "Entering a Vehicle", description: "For safety during travel." },
];

const AdhkaarHub: React.FC = () => {
    return (
        <CourseHubLayout
            title="Daily Adhkaar"
            subtitle="Memorize essential daily supplications to enrich your day."
        >
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {adhkaarList.map((item, index) => (
                    <div key={index} className="p-5 bg-white rounded-xl shadow-md border border-slate-200 flex flex-col justify-between">
                        <div>
                            <h3 className="text-lg font-bold text-slate-800">{item.title}</h3>
                            <p className="text-slate-600 text-sm mt-1">{item.description}</p>
                        </div>
                        <button className="mt-4 w-full bg-slate-200 text-slate-500 font-bold py-2 px-4 rounded-lg cursor-not-allowed">
                            Coming Soon
                        </button>
                    </div>
                ))}
            </div>
        </CourseHubLayout>
    );
};

export default AdhkaarHub;