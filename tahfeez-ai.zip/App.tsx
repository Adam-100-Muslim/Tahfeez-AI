import React, { useState, useCallback } from 'react';
import LessonView from './components/LessonView';
import OnboardingWelcome from './components/Onboarding/OnboardingWelcome';
import DailyGoal from './components/Onboarding/DailyGoal';
import LevelSelect from './components/Onboarding/LevelSelect';
import CourseSelect from './components/Onboarding/CourseSelect';
import QuranHub from './components/CourseHubs/QuranHub';
import AlphabetHub from './components/CourseHubs/AlphabetHub';
import AdhkaarHub from './components/CourseHubs/AdhkaarHub';
import SalahDhikrsHub from './components/CourseHubs/SalahDhikrsHub';

type View =
  | { screen: 'ONBOARDING'; step: 'welcome' | 'dailyGoal' | 'level' | 'course' }
  | { screen: 'COURSE_HUB' }
  | { screen: 'LESSON'; lesson: { surah: string; ayah: number; title: string } };

interface UserPreferences {
    dailyGoal: number | null;
    level: string | null;
    course: string | null;
}

function App() {
  const [view, setView] = useState<View>({ screen: 'ONBOARDING', step: 'welcome' });
  const [userPreferences, setUserPreferences] = useState<UserPreferences>({
      dailyGoal: null,
      level: null,
      course: null
  });

  const handleWelcomeContinue = useCallback(() => {
      setView({ screen: 'ONBOARDING', step: 'dailyGoal' });
  }, []);

  const handleGoalSelect = useCallback((minutes: number) => {
      setUserPreferences(prev => ({ ...prev, dailyGoal: minutes }));
      setView({ screen: 'ONBOARDING', step: 'level' });
  }, []);

  const handleLevelSelect = useCallback((level: string) => {
      setUserPreferences(prev => ({ ...prev, level }));
      setView({ screen: 'ONBOARDING', step: 'course' });
  }, []);

  const handleCourseSelect = useCallback((course: string) => {
      setUserPreferences(prev => ({ ...prev, course }));
      setView({ screen: 'COURSE_HUB' });
  }, []);

  const handleStartLesson = useCallback((surah: string, ayah: number) => {
    setView({
      screen: 'LESSON',
      lesson: { surah, ayah, title: `${surah} | Verse ${ayah}` },
    });
  }, []);

  const handleLessonComplete = useCallback(() => {
    setView({ screen: 'COURSE_HUB' });
  }, []);
  
  const renderContent = () => {
      switch(view.screen) {
          case 'ONBOARDING':
              switch(view.step) {
                  case 'welcome':
                      return <OnboardingWelcome onContinue={handleWelcomeContinue} />;
                  case 'dailyGoal':
                      return <DailyGoal onContinue={handleGoalSelect} />;
                  case 'level':
                      return <LevelSelect onContinue={handleLevelSelect} />;
                  case 'course':
                      return <CourseSelect onStart={handleCourseSelect} />;
              }
          
          case 'COURSE_HUB':
              switch (userPreferences.course) {
                  case 'quran':
                      return <QuranHub onStartLesson={handleStartLesson} />;
                  case 'alphabets':
                      return <AlphabetHub />;
                  case 'adhkaars':
                      return <AdhkaarHub />;
                  case 'salah':
                      return <SalahDhikrsHub />;
                  default:
                      // Fallback if no course is selected, go back to onboarding
                      return <OnboardingWelcome onContinue={handleWelcomeContinue} />;
              }

          case 'LESSON':
              return (
                  <LessonView 
                    key={`${view.lesson.surah}-${view.lesson.ayah}`}
                    surah={view.lesson.surah}
                    ayah={view.lesson.ayah}
                    lessonTitle={view.lesson.title}
                    onLessonComplete={handleLessonComplete}
                  />
              );

          default:
              return <OnboardingWelcome onContinue={handleWelcomeContinue} />;
      }
  };

  return (
    <div className="bg-slate-50 font-sans text-slate-800 min-h-screen">
      {renderContent()}
    </div>
  );
}

export default App;