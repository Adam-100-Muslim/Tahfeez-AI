import React from 'react';
import { StarIcon } from './IconComponents';

interface LessonCompleteProps {
    score: number;
    totalQuestions: number;
    onRetry: () => void;
    onComplete: () => void;
}

const LessonComplete: React.FC<LessonCompleteProps> = ({ score, totalQuestions, onRetry, onComplete }) => {
    const accuracy = totalQuestions > 0 ? Math.round((score / (totalQuestions * 10)) * 100) : 0;

    return (
        <div className="text-center flex flex-col items-center justify-center h-full">
            <StarIcon className="w-24 h-24 text-amber-400 mb-4" />
            <h2 className="text-3xl font-bold text-slate-800 mb-2">Lesson Complete!</h2>
            <p className="text-slate-600 text-lg mb-8">Great job, you're one step closer to mastery.</p>

            <div className="flex space-x-8 text-center mb-10">
                <div>
                    <p className="text-3xl font-bold text-emerald-500">{score}</p>
                    <p className="text-slate-500">Total XP</p>
                </div>
                <div>
                    <p className="text-3xl font-bold text-sky-500">{accuracy}%</p>
                    <p className="text-slate-500">Accuracy</p>
                </div>
            </div>

            <div className="w-full max-w-sm flex flex-col items-center space-y-3">
                 <button
                    onClick={onComplete}
                    className="w-full bg-emerald-500 text-white font-bold py-4 px-6 rounded-xl shadow-lg hover:bg-emerald-600 transition-all duration-200 transform hover:scale-105"
                >
                    Continue
                </button>
                <button
                    onClick={onRetry}
                    className="w-full text-slate-500 font-bold py-3 px-6 rounded-xl hover:bg-slate-200 transition-all"
                >
                    Practice Again
                </button>
            </div>
        </div>
    );
};

export default LessonComplete;