import React from 'react';
import { FlameIcon, GemIcon, HeartIcon } from './IconComponents';

interface HeaderProps {
    hearts: number;
    lessonTitle?: string;
}

const Header: React.FC<HeaderProps> = ({ hearts, lessonTitle }) => {
    return (
        <header className="w-full max-w-4xl mx-auto p-4">
            <div className="flex justify-between items-center">
                <h1 className="text-xl font-bold text-slate-600">{lessonTitle || 'Quranic Quest'}</h1>
                <div className="flex items-center space-x-4">
                    <div className="flex items-center space-x-1 text-orange-500">
                        <FlameIcon className="w-6 h-6"/>
                        <span className="font-bold text-lg">12</span>
                    </div>
                    <div className="flex items-center space-x-1 text-sky-500">
                        <GemIcon className="w-6 h-6"/>
                        <span className="font-bold text-lg">250</span>
                    </div>
                    <div className="flex items-center space-x-1 text-red-500">
                        <HeartIcon className="w-6 h-6"/>
                        <span className="font-bold text-lg">{hearts}</span>
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;
